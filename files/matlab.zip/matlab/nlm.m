function dvdt = nlm(t, v, cOverM, alpha, dOverM, u)
%
% nonlinear model:
%
%   vDot + (c/m) tan ((1/alpha) v) = (d/m) u
%
% static response:
%
%   v = alpha atan(d/c u)
%
% from static model: 
%
%   d/c = beta
%
% from linearization:
% 
%   vDot + (a c / m) v = (d/m) u
%
% if alpha, beta and the time-constant (tau) are given we match 
% the linear damping by setting  
%
%   c/m = alpha / tau
%
% and then 
% 
%   d/m = beta * c/m
%
dvdt = dOverM * u - cOverM * tan(v/alpha);